package project;

import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractTransformer;

public class DBException extends AbstractTransformer {

	@Override
	protected Object doTransform(Object src, String enc) throws TransformerException {
		
		ExcJson err = new ExcJson();
		err.setMessage("No Record Found");
		return err;
	}
	
}

class ExcJson{
	public String errorMessage;
	public void setMessage(String message){
		this.errorMessage = message;
	}
	
}
