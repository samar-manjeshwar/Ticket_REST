package project;
import java.util.HashMap;
import java.util.ArrayList;

public class ExceptionJson {

	public String message;
	public ArrayList<HashMap<String,String>> errors;
	
}
