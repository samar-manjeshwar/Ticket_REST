package project;

import java.sql.Timestamp;

public class TicketIn {

	public int ID;
	public String customer_ID;
	public String user_ID;
	public String group_ID;
	public String label_ID;
	public String state;
	public String subject;
	public String reply_to;
	public String reply_cc;
	public boolean spam;
	public boolean trash;
	public Timestamp updated_at;
	public Timestamp created_at;
	
	public void setID(int ID){
		this.ID = ID;
	}
	public void setCustomer_ID(String customer_ID){
		this.customer_ID = customer_ID;
	}
	public void setUser_ID(String user_ID){
		this.user_ID = user_ID;
	}
	public void setGroup_ID(String group_ID){
		this.group_ID = group_ID;
	}
	public void setLabel_ID(String label_ID){
		this.label_ID = label_ID;
	}
	public void setState(String state){
		this.state = state;
	}
	public void setSubject(String subject){
		this.subject = subject;
	}
	public void setReply_To(String reply_To){
		this.reply_to = reply_To;
	}
	public void setReply_Cc(String reply_Cc){
		this.reply_cc = reply_Cc;
	}
	public void setSpam(boolean spam){
		this.spam = spam;
	}
	public void setTrash(boolean trash){
		this.trash = trash;
	}
	public void setUpdated_At(Timestamp updated_At){
		this.updated_at = updated_At;
	}
	public void setUpdated_At(String updated_at){
		Object temp = (Object)updated_at;
		this.updated_at = (Timestamp)temp;
	}
	public void setCreated_At(Timestamp created_At){
		this.created_at = created_At;
	}
	public void setCreated_At(String created_at){
		Object temp = (Object)created_at;
		this.created_at = (Timestamp)temp;
	}
}
