package project;

import org.postgresql.util.PSQLException;

@SuppressWarnings("serial")
public class badConnectionException extends Exception{
	
	public badConnectionException(PSQLException e){
		super(e.getMessage());
	}
}
