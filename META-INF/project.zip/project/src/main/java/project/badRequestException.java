package project;

import org.mule.transport.http.components.BadRequestException;

@SuppressWarnings("serial")
public class badRequestException extends Exception{

	public badRequestException(BadRequestException e){
		super(e.getMessage());
	}
}
