package project;

import java.util.ArrayList;
import java.util.HashMap;

import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractTransformer;

public class buildExceptionJson extends AbstractTransformer{

	@Override
	protected Object doTransform(Object src, String enc) throws TransformerException {
		
		ExceptionJson ej = new ExceptionJson();
		
		String pay = (String)src;
		
		String[] s1 = pay.split("message:");
		ArrayList<HashMap<String,String>> temp = new ArrayList<HashMap<String,String>>();
		
		ej.message = s1[0];
		for(int i=1;i<s1.length;i++){
			HashMap<String,String> hm = new HashMap<String,String>();
			hm.put("message", s1[i]);
			temp.add(hm);
			
			
		}
		ej.errors = temp;
		
		return ej;
	}

}
