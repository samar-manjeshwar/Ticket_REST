package project;

import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.module.http.internal.ParameterMap;
import org.mule.transformer.AbstractMessageTransformer;

public class buildQueryString extends AbstractMessageTransformer {

	@Override
	public Object transformMessage(MuleMessage message, String outputEncoding) throws TransformerException {
		
		
		
		ParameterMap pm = new ParameterMap();
		String fields = "";
		pm = message.getInboundProperty("http.query.params");
		if(pm.containsKey("fields")){
			
			fields = pm.get("fields");
			message.setInvocationProperty("fields", fields);
			
		}
		else{
			fields = "*";
		}
		if(pm.containsKey("sort")){
			message.setInvocationProperty("orderby", pm.get("sort"));
		}
		else
			message.setInvocationProperty("orderby", "id");
		if(pm.containsKey("state")){
			message.setInvocationProperty("state", pm.get("state"));
		}
		else
			message.setInvocationProperty("state", "'read','hold','open'");
		
		
		return message;
	}

}
