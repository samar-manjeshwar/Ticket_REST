package project;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.HashSet;
import org.mule.module.json.JsonData;


public class convertToTicket {


	 public Object doTransform(JsonData src) throws validationException{

		//payload is an object of JsonData
		
		
		int flag = 0;
		HashSet<String> errorSet = new HashSet<String>();
		String exception;
		String finalException="";
		
		TicketIn t = new TicketIn();
			
			try{
				String str = src.getAsString("label_id");
				StringBuilder sb = new StringBuilder();
				char[] strArr = str.toCharArray();
				for(char ch: strArr){
					if(ch != '[' && ch != ']' && ch != '"'){
							sb.append(ch);
					}
				}
				t.setLabel_ID(sb.toString());
			}
			catch(Exception e){
				exception = "message : label_id error";
				finalException = finalException + "\n";
				finalException = finalException + "message:label_id error";
				errorSet.add(exception);
				flag = 1;
			}
			try{
				t.setCustomer_ID(src.getAsString("customer_id"));
			}
			catch(Exception e){
				exception = "message : customer_id error";
				finalException = finalException + "\n";
				finalException = finalException + "message:customer_id error";
				errorSet.add(exception);
				flag = 1;
			}
			try{
				t.setUser_ID(src.getAsString("user_id"));
			}
			catch(Exception e){
				exception = "message : user_id error";
				finalException = finalException + "\n";
				finalException = finalException + "message:user_id error";
				errorSet.add(exception);
				flag = 1;
			}
			try{
				t.setGroup_ID(src.getAsString("group_id"));
			}
			catch(Exception e){
				exception = "message : group_id error";
				finalException = finalException + "\n";
				finalException = finalException + "message:group_id error";
				errorSet.add(exception);
				flag = 1;
			}
			try{
				t.setState(src.getAsString("state"));
			}
			catch(Exception e){
				exception = "message : state error";
				finalException = finalException + "\n";
				finalException = finalException + "message:state error";
				errorSet.add(exception);
				flag = 1;
			}
			try{
				t.setSubject(src.getAsString("subject"));
			}
			catch(Exception e){
				exception = "message : subject error";
				finalException = finalException + "\n";
				finalException = finalException + "message:subject error";
				errorSet.add(exception);
				flag = 1;
			}
			try{
				t.setReply_To(src.getAsString("reply_to"));
			}
			catch(Exception e){
				exception = "message : reply_to error";
				finalException = finalException + "\n";
				finalException = finalException + "message:reply_to error";
				errorSet.add(exception);
				flag = 1;
			}
			try{
				t.setReply_Cc(src.getAsString("reply_cc"));
			}
			catch(Exception e){
				exception = "message : reply_cc error";
				finalException = finalException + "\n";
				finalException = finalException + "message:reply_cc error";
				errorSet.add(exception);
				flag = 1;
			}
			try{
				if(src.getAsString("spam") == "false"){
					t.setSpam(false);
				}
				else if(src.getAsString("spam") == "true"){
					t.setSpam(true);
				}
			}
			catch(Exception e){
				exception = "message : spam error";
				finalException = finalException + "\n";
				finalException = finalException + "message:spam error";
				errorSet.add(exception);
				flag = 1;
			}
			try{
				if(src.getAsString("trash") == "true"){
					t.setTrash(true);
				}
				else if(src.getAsString("trash") == "false"){
					t.setTrash(false);
				}
			}
			catch(Exception e){
				exception = "message : trash error";
				finalException = finalException + "\n";
				finalException = finalException + "message:trash error";
				errorSet.add(exception);
				flag = 1;
			}
			
			Calendar calendar = Calendar.getInstance();
			java.util.Date now = calendar.getTime();
			t.setUpdated_At(new Timestamp(now.getTime()));
			t.setCreated_At(new Timestamp(now.getTime()));
			
			
			if(flag != 0){
				throw new validationException(finalException);
			}
			return t;
		
	}

}


