package project;

import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractTransformer;
import org.mule.util.CaseInsensitiveHashMap;

import java.sql.Timestamp;
import java.util.LinkedList;

public class messageProcessorJava extends AbstractTransformer {

	@Override
	protected Object doTransform(Object src, String enc) throws TransformerException {
		
		Message msg = new Message();
		for(CaseInsensitiveHashMap hm:(LinkedList<CaseInsensitiveHashMap>)src){
			
			msg.setID((int) hm.get("ID"));
			msg.setFK_message_ID((int)hm.get("FK_message_ID"));
			msg.setFrom_name((String) (hm.get("from_name")));
			msg.setBody((String) hm.get("body"));
			msg.setHtmlized((boolean) hm.get("htmlized"));
			msg.setUser_ID((String)hm.get("user_ID"));
			msg.setType((String) hm.get("msg_type"));
			msg.setCreated_at((Timestamp) hm.get("created_at"));
			msg.setFrom_email((String) hm.get("from_email"));
			msg.setTo_email((String) hm.get("to_email"));
			msg.setEmail_cc((String) hm.get("mail_cc"));
			msg.setEmail_bcc((String) hm.get("mail_bcc"));
			msg.setReply_to((String) hm.get("reply_to"));
			msg.setSubject((String) hm.get("subject"));
			
		}
		
		return msg;
	}

}

class Message{
	
	public int ID;
	public int FK_message_ID;
	public String from_name;
	public String body;
	public boolean htmlized;
	public String user_id;
	public String type;
	public Timestamp created_at;
	public String from_email;
	public String to_email;
	public String mail_cc;
	public String mail_bcc;
	public String reply_to;
	public String subject;
	
	public void setID(int ID){
		this.ID = ID;
	}
	public void setFK_message_ID(int FK_message_ID){
		this.FK_message_ID = FK_message_ID;
	}
	public void setFrom_name(String from_name){
		this.from_name = from_name;
	}
	public void setBody(String body){
		this.body = body;
	}
	public void setHtmlized(boolean htmlized){
		this.htmlized = htmlized;
	}
	public void setUser_ID(String user_ID){
		this.user_id = user_ID;
	}
	public void setType(String type){
		this.type = type;
	}
	public void setCreated_at(Timestamp created_at){
		this.created_at = created_at;
	}
	public void setFrom_email(String from_email){
		this.from_email = from_email;
	}
	public void setTo_email(String to_email){
		this.to_email = to_email;
	}
	public void setEmail_cc(String email_cc){
		this.mail_cc = email_cc;
	}
	public void setEmail_bcc(String email_bcc){
		this.mail_bcc = email_bcc;
	}
	public void setReply_to(String reply_to){
		this.reply_to = reply_to;
	}
	public void setSubject(String subject){
		this.subject = subject;
	}
	
}
