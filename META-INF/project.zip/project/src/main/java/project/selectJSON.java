package project;

import org.codehaus.jackson.JsonNode;
import org.json.JSONObject;
import org.mule.api.transformer.TransformerException;
import org.mule.module.json.JsonData;
import org.mule.transformer.AbstractTransformer;

import java.io.IOException;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Map;

import org.mule.util.CaseInsensitiveHashMap;

public class selectJSON extends AbstractTransformer{

	@Override
	protected Object doTransform(Object src, String enc) throws TransformerException {
		
		
		return src;
	}

}
