package project;

import java.util.HashMap;
import java.util.LinkedList;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.SerializationConfig;
import org.apache.commons.collections.map.AbstractHashedMap;
import java.sql.Timestamp;
import org.json.JSONArray;
import org.json.JSONObject;
import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractTransformer;
import org.mule.util.CaseInsensitiveHashMap;

public class stringtoJsonJava extends AbstractTransformer {

	@Override
	protected Object doTransform(Object src, String enc) throws TransformerException {
		
		
		LinkedList<HashMap<String,String>> Json = new LinkedList<HashMap<String,String>>();
		
		System.out.println(src.toString());
		String[] part = new String[]{};
		Ticket t;
		LinkedList<Ticket> ticketList = new LinkedList<Ticket>();
		
		for(CaseInsensitiveHashMap obj: (LinkedList<CaseInsensitiveHashMap>)src){
			t = new Ticket();
			String temp = (String) obj.get("label_ID");
			if(temp!=null){
				part = temp.split(",");
				t.setLabel_ID(part);
				//Json.add("label_ID",part);
			}
			else
			t.setLabel_ID(part);
			if(obj.get("ID")!=null){
				t.setID((int)obj.get("ID"));
			}
			else
				t.setID(00);
			t.setCustomer_ID((String)obj.get("customer_ID"));
			t.setUser_ID((String)obj.get("user_ID"));
			t.setGroup_ID((String)obj.get("group_ID"));
			t.setState((String)obj.get("state"));
			t.setSubject((String)obj.get("subject"));
			t.setReply_To((String)obj.get("reply_to"));
			t.setReply_Cc((String)obj.get("reply_cc"));
			if(obj.get("spam")!=null)
				t.setSpam((boolean)obj.get("spam"));
			if(obj.get("trash")!=null)
				t.setTrash((boolean)obj.get("trash"));
			if(obj.get("updated_at")!=null)
				t.setUpdated_At((Timestamp)obj.get("updated_at"));
			if(obj.get("created_at")!=null)
				t.setCreated_At((Timestamp)obj.get("created_at"));
			
			ticketList.add(t);
			
		}
		
		
		
		
		return ticketList;
	}

}

class Ticket{
	
	public int ID;
	public String customer_ID;
	public String user_ID;
	public String group_ID;
	public String[] labelID;
	public String state;
	public String subject;
	public String reply_to;
	public String reply_cc;
	public boolean spam;
	public boolean trash;
	public Timestamp updated_at;
	public Timestamp created_at;
	
	public void setID(int ID){
		this.ID = ID;
	}
	public void setCustomer_ID(String customer_ID){
		this.customer_ID = customer_ID;
	}
	public void setUser_ID(String user_ID){
		this.user_ID = user_ID;
	}
	public void setGroup_ID(String group_ID){
		this.group_ID = group_ID;
	}
	public void setLabel_ID(String[] label_ID){
		this.labelID = label_ID;
	}
	public void setState(String state){
		this.state = state;
	}
	public void setSubject(String subject){
		this.subject = subject;
	}
	public void setReply_To(String reply_To){
		this.reply_to = reply_To;
	}
	public void setReply_Cc(String reply_Cc){
		this.reply_cc = reply_Cc;
	}
	public void setSpam(boolean spam){
		this.spam = spam;
	}
	public void setTrash(boolean trash){
		this.trash = trash;
	}
	public void setUpdated_At(Timestamp updated_At){
		this.updated_at = updated_At;
	}
	public void setUpdated_At(String updated_at){
		Object temp = (Object)updated_at;
		this.updated_at = (Timestamp)temp;
	}
	public void setCreated_At(Timestamp created_At){
		this.created_at = created_At;
	}
	public void setCreated_At(String created_at){
		Object temp = (Object)created_at;
		this.created_at = (Timestamp)temp;
	}
}
