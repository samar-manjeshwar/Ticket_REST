package project;

import org.mule.api.transformer.TransformerException;
import org.mule.module.json.JsonData;
import org.mule.transformer.AbstractTransformer;

public class updateTickeInClass extends AbstractTransformer{

	@Override
	protected Object doTransform(Object src, String enc) throws TransformerException {
		TicketIn t = new TicketIn();
		JsonData jd = (JsonData)src;
		t.setGroup_ID(jd.getAsString("group_id"));
		
		
		return t;
	}

}
