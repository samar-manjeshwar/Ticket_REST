package project;

@SuppressWarnings("serial")
public class validationException extends Exception{

	public validationException(String auth){
		super(auth);
	}
}
